Remember to think of the "CellRenderer" as a set of instructions that dertermine what
will be rendered at each cell. It uses coordinates to have conditional rendering logic.

This directory should have all the CellRenderer implementations. There should be one per
grid.