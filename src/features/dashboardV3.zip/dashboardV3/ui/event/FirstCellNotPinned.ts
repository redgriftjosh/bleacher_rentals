import { Application, Sprite } from "pixi.js";
import { EventInfo } from "../../util/Events";
import { EventBody } from "./EventBody";
import { Baker } from "../../util/Baker";
import { PinnableSection } from "./PinnableSection";

/**
 * Static event label component without any interactive elements
 * This can be safely baked into a RenderTexture for performance
 */
export class FirstCellNotPinned extends Sprite {
  constructor(
    eventInfo: EventInfo,
    firstVisibleColIndex: number,
    currentColIndex: number,
    app: Application,
    baker: Baker,
    dimensions: { width: number; height: number }
  ) {
    super();

    const texture = baker.getTexture(
      `FirstEventCell:${eventInfo.span?.ev.bleacherEventId}`,
      // { width: dimensions.width * 2, height: dimensions.height },
      null,
      (c) => {
        const eventCell = new EventBody(eventInfo, baker, dimensions);
        c.addChild(eventCell);

        const eventCellLabel = new PinnableSection(eventInfo.span!, app, baker);
        c.addChild(eventCellLabel);
      }
    );

    this.texture = texture;
  }

  /**
   * Get the dimensions needed for positioning additional elements
   */
  public getLabelDimensions(): { width: number; height: number } {
    const bounds = this.getBounds();
    return { width: bounds.width, height: bounds.height };
  }
}
